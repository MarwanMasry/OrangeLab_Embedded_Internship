var searchData=
[
  ['high_5fbyte_5ffirst_418',['HIGH_BYTE_FIRST',['../_platform___types_8h.html#a53d883f1077107cc6207cbc86771a896',1,'Platform_Types.h']]]
];
