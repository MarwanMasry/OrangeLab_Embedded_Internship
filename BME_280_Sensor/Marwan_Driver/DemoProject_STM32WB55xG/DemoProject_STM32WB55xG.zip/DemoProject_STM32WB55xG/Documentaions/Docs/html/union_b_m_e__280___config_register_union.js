var union_b_m_e__280___config_register_union =
[
    [ "__pad0__", "union_b_m_e__280___config_register_union.html#afc0f36dcc0893bc472030a6ae0e81fb3", null ],
    [ "Bits", "union_b_m_e__280___config_register_union.html#ac4d34119b3ac2730b7ccf9e41bec4d59", null ],
    [ "config", "union_b_m_e__280___config_register_union.html#a3ffa62fd7e1091367befeeccee8713bb", null ],
    [ "filter_coeff", "union_b_m_e__280___config_register_union.html#a42522ad529e4b5ad1279b985707a1592", null ],
    [ "spi3w_en", "union_b_m_e__280___config_register_union.html#a87ab5cdcba77d8f4c82b93783df76501", null ],
    [ "t_sb", "union_b_m_e__280___config_register_union.html#af8b817fa6131fce8593b6cd4bc6021b5", null ]
];