var union_b_m_e280___ctrl_meas_register_union =
[
    [ "Bits", "union_b_m_e280___ctrl_meas_register_union.html#a207cafe102fbbab9c794211d9ea7d615", null ],
    [ "config", "union_b_m_e280___ctrl_meas_register_union.html#a2a523f69984cdfe22eb492a68a5d7240", null ],
    [ "mode", "union_b_m_e280___ctrl_meas_register_union.html#aee2602e964036c3739ab6c12044d30bb", null ],
    [ "osrs_p", "union_b_m_e280___ctrl_meas_register_union.html#a600854065c5caee2ea975d52dc773a9b", null ],
    [ "osrs_t", "union_b_m_e280___ctrl_meas_register_union.html#a237e8236e986649b7229452d2af5ae98", null ]
];