var _b_m_e__280___registers_8h =
[
    [ "BME280_CHIP_ID_ADDR", "_b_m_e__280___registers_8h.html#afc2c2e977533781c8fad2dc1a9408b4e", null ],
    [ "BME280_CONFIG_ADDR", "_b_m_e__280___registers_8h.html#a7c2fa57fdeb63ca2c255432f4c98298e", null ],
    [ "BME280_CTRL_HUM_ADDR", "_b_m_e__280___registers_8h.html#a8f090989bb45d85c2605e4a86a49b46d", null ],
    [ "BME280_CTRL_MEAS_ADDR", "_b_m_e__280___registers_8h.html#a53b7ccb8b940a9bdd861a7722732c9cc", null ],
    [ "BME280_DATA_START_ADDR", "_b_m_e__280___registers_8h.html#a181aaf8e827408ac057a209b85880f6d", null ],
    [ "BME280_HUMIDITY_CALIB_DATA_ADDR", "_b_m_e__280___registers_8h.html#ab3deba49b93318f0daa9e9aa238d8299", null ],
    [ "BME280_PWR_CTRL_ADDR", "_b_m_e__280___registers_8h.html#a98ddb9dc59edd34aa1d9ea44a05feb7b", null ],
    [ "BME280_RESET_ADDR", "_b_m_e__280___registers_8h.html#a946f939c2dda53735f06cb86abb216e4", null ],
    [ "BME280_STATUS_ADDR", "_b_m_e__280___registers_8h.html#a4c24f9719642803fe7ea624ba487645b", null ],
    [ "BME280_TEMP_PRESS_CALIB_DATA_ADDR", "_b_m_e__280___registers_8h.html#a312afdb80e73c77393ea9aac287b42f5", null ]
];