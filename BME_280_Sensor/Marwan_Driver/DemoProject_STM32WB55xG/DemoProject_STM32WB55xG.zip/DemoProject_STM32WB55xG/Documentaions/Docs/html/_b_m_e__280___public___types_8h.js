var _b_m_e__280___public___types_8h =
[
    [ "BME_280_OversamplingSettings", "struct_b_m_e__280___oversampling_settings.html", "struct_b_m_e__280___oversampling_settings" ],
    [ "BME_280_settings", "struct_b_m_e__280__settings.html", "struct_b_m_e__280__settings" ],
    [ "BME_280_Config", "_b_m_e__280___public___types_8h.html#a148c2ad66f772f3f2744793998a82552", null ],
    [ "BME_280_CommunicationProtocol", "_b_m_e__280___public___types_8h.html#ab62b2899dace129af2927b22bd3b409a", [
      [ "BME_280_INTERFACE_SPI", "_b_m_e__280___public___types_8h.html#ab62b2899dace129af2927b22bd3b409aa08cd0efa0353d982bfe2269af01cc965", null ],
      [ "BME_280_INTERFACE_I2C", "_b_m_e__280___public___types_8h.html#ab62b2899dace129af2927b22bd3b409aa305d76e70b0acdc94157419db259dcad", null ]
    ] ],
    [ "BME_280_FilterCoefficient", "_b_m_e__280___public___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6", [
      [ "FILTER_OFF", "_b_m_e__280___public___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6ab1577adfe34e9a7249c80578493a2a85", null ],
      [ "_2", "_b_m_e__280___public___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6a4ac9fde21efe0b04d986336be5ff19ea", null ],
      [ "_4", "_b_m_e__280___public___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6aa0a2cbf1b2f9a4f01c68830ebc853b96", null ],
      [ "_8", "_b_m_e__280___public___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6a29bf2b556dc552c594d3f26fd88d4867", null ],
      [ "_16", "_b_m_e__280___public___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6aa8860397c1b4c5206139a0582a8cad88", null ]
    ] ],
    [ "BME_280_Mode", "_b_m_e__280___public___types_8h.html#a4c027fadb628675a569c2b1e781b6576", [
      [ "SLEEP_MODE", "_b_m_e__280___public___types_8h.html#a4c027fadb628675a569c2b1e781b6576ad1486bda2c3e55fd939260a6b7e38020", null ],
      [ "FORCED_MODE", "_b_m_e__280___public___types_8h.html#a4c027fadb628675a569c2b1e781b6576af93f7214719796eb62d49359c1c5eb05", null ],
      [ "NORMAL_MODE", "_b_m_e__280___public___types_8h.html#a4c027fadb628675a569c2b1e781b6576a83feb61d42f8db9f494019fcea2c0148", null ]
    ] ],
    [ "BME_280_OversamplingValue", "_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7", [
      [ "SKIPPED", "_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a7b3e3be20ffe941881dfab27e5f6fd7e", null ],
      [ "OVERSAMPLING_1", "_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7afb934501128d3db119c09619681736f0", null ],
      [ "OVERSAMPLING_2", "_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a3f6d80c62d64464c75826d601d878b15", null ],
      [ "OVERSAMPLING_4", "_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a08c7e75e851365b47a7aa08130e0f176", null ],
      [ "OVERSAMPLING_8", "_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a69987d0e93c44cef825208793d2fb612", null ],
      [ "OVERSAMPLING_16", "_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7acedf04c432418a93303824703f419950", null ]
    ] ],
    [ "BME_280_StandbyTimeInNormalMode", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03", [
      [ "_HALF_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03aaf53011d054cb6994521ed9a13f0cecd", null ],
      [ "_62_AND_HALF_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a25343eda9a950ca53191a9907bc59d41", null ],
      [ "_125_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a7996c77b155b3d8f3c9e5f35970f5f29", null ],
      [ "_250_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03afd045a3082d62e4ad74d3c76f51d9108", null ],
      [ "_500_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a126b23d9a5e1b2ccc0fcc1cfa73484b0", null ],
      [ "_1000_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03ae025f4c99442d9a61023739eecdd65f0", null ],
      [ "_10_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a18a8d67e4539244782d601b46df7e9d0", null ],
      [ "_20_MS", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a20f6959900f2ff118ab6957c629b17a2", null ],
      [ "NO_STANDBY_TIME_NOT_IN_NORMAL_MODE", "_b_m_e__280___public___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a1804730b010c1fe93b04c9e90299d306", null ]
    ] ],
    [ "BME_280_Status", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21c", [
      [ "BME280_OK", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca145f443f01c559fdc955ed59eaabf7f3", null ],
      [ "BME280_NULL_ERROR", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca37bede043b5035d40cdfb79787d07dc8", null ],
      [ "BME280_COMM_ERROR", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21cafbe01beed803a8c76e21b8d59935752f", null ],
      [ "BME280_ERROR", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca34fe575d57e5559a9428d366b0b1abe5", null ],
      [ "BME280_NOT_OK", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca23e10c7ac0c4cdeecfea8d7587d8b78c", null ],
      [ "BME280_ERROR_INSTANCE_ALEARDY_TAKEN", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21cacc10e91c76fc0029cb4e5362eec73d66", null ],
      [ "BME280_NO_INSTANCES_AVALIABLE", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca7bab7de96763824d3375704722cf5401", null ],
      [ "BME280_INTERFACE_UNKNOWN", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21cacca9cf427725b431b4636dd5c10cce02", null ],
      [ "BME280_NOT_INITIALIZED", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21cab0749cb9ff8ada67a8857e040e92f3e6", null ],
      [ "BME280_ERROR_CANNOT_SET_T_SB_NOT_IN_NORMAL_MODE", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca2116b8fe6be3f9bffd74a9d34dd244c0", null ],
      [ "BME280_ERROR_CANNOT_GET_T_SB_NOT_IN_NORMAL_MODE", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca51ada2b7b4230cf1c6ac207f1fb8a011", null ],
      [ "BME280_EXCEEDED_MIN_RANGE", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca422d08d7fb3fde2bf38cc719f5668ab7", null ],
      [ "BME280_EXCEEDED_MAX_RANGE", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca14a8c36a46ddac46f2afd3b4a366faf0", null ],
      [ "BME280_SETTINGS_FAILED_TO_BE_SET", "_b_m_e__280___public___types_8h.html#ac84c9ca1d646ac3751ec0b1780c7f21ca3becd2c2ca016daabc8c9dc9fe6f67c4", null ]
    ] ]
];