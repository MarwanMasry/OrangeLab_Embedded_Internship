var _b_m_e__280___private___types_8h =
[
    [ "BME_280_ConfigRegisterUnion", "union_b_m_e__280___config_register_union.html", "union_b_m_e__280___config_register_union" ],
    [ "BME280_TemperatureReading", "union_b_m_e280___temperature_reading.html", "union_b_m_e280___temperature_reading" ],
    [ "BME280_PressureReading", "union_b_m_e280___pressure_reading.html", "union_b_m_e280___pressure_reading" ],
    [ "BME280_HumidityReading", "union_b_m_e280___humidity_reading.html", "union_b_m_e280___humidity_reading" ],
    [ "BME280_CtrlMeasRegisterUnion", "union_b_m_e280___ctrl_meas_register_union.html", "union_b_m_e280___ctrl_meas_register_union" ],
    [ "BME280_CtrlHumRegisterUnion", "union_b_m_e280___ctrl_hum_register_union.html", "union_b_m_e280___ctrl_hum_register_union" ],
    [ "BME280_StatusRegisterUnion", "union_b_m_e280___status_register_union.html", "union_b_m_e280___status_register_union" ],
    [ "BME_280_Configurations", "struct_b_m_e__280___configurations.html", "struct_b_m_e__280___configurations" ],
    [ "BME280_HUMIDITY_CALIB_DATA_LEN", "_b_m_e__280___private___types_8h.html#a3768333f53ae57f3047838552e7771d5", null ],
    [ "BME280_PRESS_TEMP_HUMI_DATA_LEN", "_b_m_e__280___private___types_8h.html#ad954e10d87ed86cb03041eee83dfcd75", null ],
    [ "BME280_SOFT_RESET_COMMAND", "_b_m_e__280___private___types_8h.html#a459aacfaccab02562d4aa0c7c8fc6632", null ],
    [ "BME280_TEMP_PRESS_CALIB_DATA_LEN", "_b_m_e__280___private___types_8h.html#ab44aa25677fa7fcab0a4ccc59b050286", null ],
    [ "IM_UPDATE_MASK", "_b_m_e__280___private___types_8h.html#aa7139e4dec126d9378e47c8d1b44bdbb", null ],
    [ "INSTANCE_NOT_TAKEN", "_b_m_e__280___private___types_8h.html#a6cf220b6f9aa08ddf3bc23709cc56b86", null ],
    [ "INSTANCE_TAKEN", "_b_m_e__280___private___types_8h.html#a95fcdcc8e6585d3e9c00b774d50b789e", null ],
    [ "NOT_OCCUIPIED", "_b_m_e__280___private___types_8h.html#ab8414603a8c8f3ac317ee624db59bb82", null ],
    [ "OCCUIPIED", "_b_m_e__280___private___types_8h.html#ad4dd970e3bb2923bdd4828024711b1b1", null ],
    [ "SPI_READ_MASK", "_b_m_e__280___private___types_8h.html#ad919e84c8ccdc45cf399364474f40f62", null ],
    [ "SPI_WRITE_MASK", "_b_m_e__280___private___types_8h.html#a72a04f68186b1707d6c3afff1517264e", null ],
    [ "BME280_FlagStatus", "_b_m_e__280___private___types_8h.html#a9e6988e3952e7c31069a079d47137901", [
      [ "_RESET", "_b_m_e__280___private___types_8h.html#a9e6988e3952e7c31069a079d47137901a2a4d0a227471db974a5d9554112efd29", null ],
      [ "_SET", "_b_m_e__280___private___types_8h.html#a9e6988e3952e7c31069a079d47137901a9cf35841ca08d4cf3c06cdf9f7301778", null ]
    ] ],
    [ "__attribute__", "_b_m_e__280___private___types_8h.html#a3672dde901b1e31fb7a19ba524e777ec", null ],
    [ "BME280_UncompensatedReadings", "_b_m_e__280___private___types_8h.html#a183d608f4aa5243406de349f3fb2acc0", null ],
    [ "BME_280_Calib1", "_b_m_e__280___private___types_8h.html#a2c3052feded6ecc0b70c4f16cfa25114", null ],
    [ "BME_280_Calib2", "_b_m_e__280___private___types_8h.html#a1ed5616418f80a5248b1bbe58e147878", null ]
];