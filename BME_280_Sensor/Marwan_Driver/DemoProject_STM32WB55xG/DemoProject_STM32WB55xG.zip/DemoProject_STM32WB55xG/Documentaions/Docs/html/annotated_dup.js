var annotated_dup =
[
    [ "BME280_CtrlHumRegisterUnion", "union_b_m_e280___ctrl_hum_register_union.html", "union_b_m_e280___ctrl_hum_register_union" ],
    [ "BME280_CtrlMeasRegisterUnion", "union_b_m_e280___ctrl_meas_register_union.html", "union_b_m_e280___ctrl_meas_register_union" ],
    [ "BME280_HumidityReading", "union_b_m_e280___humidity_reading.html", "union_b_m_e280___humidity_reading" ],
    [ "BME280_PressureReading", "union_b_m_e280___pressure_reading.html", "union_b_m_e280___pressure_reading" ],
    [ "BME280_StatusRegisterUnion", "union_b_m_e280___status_register_union.html", "union_b_m_e280___status_register_union" ],
    [ "BME280_TemperatureReading", "union_b_m_e280___temperature_reading.html", "union_b_m_e280___temperature_reading" ],
    [ "BME_280_ConfigRegisterUnion", "union_b_m_e__280___config_register_union.html", "union_b_m_e__280___config_register_union" ],
    [ "BME_280_Configurations", "struct_b_m_e__280___configurations.html", "struct_b_m_e__280___configurations" ],
    [ "BME_280_OversamplingSettings", "struct_b_m_e__280___oversampling_settings.html", "struct_b_m_e__280___oversampling_settings" ],
    [ "BME_280_settings", "struct_b_m_e__280__settings.html", "struct_b_m_e__280__settings" ],
    [ "Std_VersionInfoType", "struct_std___version_info_type.html", "struct_std___version_info_type" ]
];