var struct_b_m_e__280___oversampling_settings =
[
    [ "humidity", "struct_b_m_e__280___oversampling_settings.html#a70129c3c69ff580e4533cfdafef32503", null ],
    [ "Pressure", "struct_b_m_e__280___oversampling_settings.html#ab451260fce541e570c8fa06b7e665645", null ],
    [ "Temperture", "struct_b_m_e__280___oversampling_settings.html#ab00d162c299560aa50261c5f98ad16ad", null ]
];