var searchData=
[
  ['float32_329',['float32',['../_platform___types_8h.html#aacdc525d6f7bddb3ae95d5c311bd06a1',1,'Platform_Types.h']]],
  ['float64_330',['float64',['../_platform___types_8h.html#a232fad1b0d6dcc7c16aabde98b2e2a80',1,'Platform_Types.h']]]
];
