var union_b_m_e280___humidity_reading =
[
    [ "Data", "union_b_m_e280___humidity_reading.html#a84aff7f4b04f8747077d96720217430b", null ],
    [ "humidity", "union_b_m_e280___humidity_reading.html#acb7d622437540eea4da00d9234df04b7", null ],
    [ "lsb", "union_b_m_e280___humidity_reading.html#ab9697f7c8643dad09da569d6e5d39446", null ],
    [ "msb", "union_b_m_e280___humidity_reading.html#a4635a3e44fd06f64f96694f68f17bbd4", null ]
];