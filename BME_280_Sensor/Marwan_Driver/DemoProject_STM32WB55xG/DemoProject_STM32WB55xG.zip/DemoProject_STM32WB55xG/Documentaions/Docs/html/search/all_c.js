var searchData=
[
  ['occuipied_173',['OCCUIPIED',['../_b_m_e__280___private___types_8h.html#ad4dd970e3bb2923bdd4828024711b1b1',1,'BME_280_Private_Types.h']]],
  ['occupied_174',['occupied',['../struct_b_m_e__280___configurations.html#a2241dca6736e4dcc9d0d92968fa2378c',1,'BME_280_Configurations']]],
  ['one_175',['ONE',['../_std___types_8h.html#a206b6f5362e56b51ca957635350b70b6',1,'Std_Types.h']]],
  ['osrs_5fp_176',['osrs_p',['../union_b_m_e280___ctrl_meas_register_union.html#a600854065c5caee2ea975d52dc773a9b',1,'BME280_CtrlMeasRegisterUnion']]],
  ['osrs_5ft_177',['osrs_t',['../union_b_m_e280___ctrl_meas_register_union.html#a237e8236e986649b7229452d2af5ae98',1,'BME280_CtrlMeasRegisterUnion']]],
  ['oversampling_5f1_178',['OVERSAMPLING_1',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7afb934501128d3db119c09619681736f0',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f16_179',['OVERSAMPLING_16',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7acedf04c432418a93303824703f419950',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f2_180',['OVERSAMPLING_2',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a3f6d80c62d64464c75826d601d878b15',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f4_181',['OVERSAMPLING_4',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a08c7e75e851365b47a7aa08130e0f176',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f8_182',['OVERSAMPLING_8',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a69987d0e93c44cef825208793d2fb612',1,'BME_280_Public_Types.h']]],
  ['oversampling_5fsettings_183',['overSampling_settings',['../struct_b_m_e__280__settings.html#a3e3cdd66a0a7ab7a880951e3a47c8543',1,'BME_280_settings']]]
];
