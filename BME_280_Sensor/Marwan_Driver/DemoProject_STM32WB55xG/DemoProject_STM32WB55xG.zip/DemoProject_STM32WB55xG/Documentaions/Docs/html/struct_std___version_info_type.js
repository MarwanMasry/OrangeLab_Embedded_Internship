var struct_std___version_info_type =
[
    [ "moduleID", "struct_std___version_info_type.html#a39e3d6d4bbac41bdba1e51e8876522d2", null ],
    [ "sw_major_version", "struct_std___version_info_type.html#ad08a3e87fe83d635d0d28fd6e99271af", null ],
    [ "sw_minor_version", "struct_std___version_info_type.html#ab27f4e07c28199c14e79d44a3ea09008", null ],
    [ "sw_patch_version", "struct_std___version_info_type.html#af9854c941ce22e88a1718fd2aa183c3c", null ],
    [ "vendorID", "struct_std___version_info_type.html#a26055f45e3016862f87063d1feccea8d", null ]
];