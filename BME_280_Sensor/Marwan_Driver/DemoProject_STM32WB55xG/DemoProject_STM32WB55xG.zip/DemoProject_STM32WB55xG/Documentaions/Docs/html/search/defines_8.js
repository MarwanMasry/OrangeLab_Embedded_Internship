var searchData=
[
  ['max_5finstance_5fof_5fbme_5f280_5fsensor_426',['MAX_INSTANCE_OF_BME_280_SENSOR',['../_b_m_e__280__cfg_8h.html#ac703acd0062c137e6494d996e8bbe945',1,'BME_280_cfg.h']]],
  ['msb_5ffirst_427',['MSB_FIRST',['../_platform___types_8h.html#ad2f1093563dc14c2923f33412a982e83',1,'Platform_Types.h']]]
];
