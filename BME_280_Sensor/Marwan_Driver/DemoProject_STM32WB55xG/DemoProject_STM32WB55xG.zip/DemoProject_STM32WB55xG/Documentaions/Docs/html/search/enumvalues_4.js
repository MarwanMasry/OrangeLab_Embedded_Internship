var searchData=
[
  ['oversampling_5f1_381',['OVERSAMPLING_1',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7afb934501128d3db119c09619681736f0',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f16_382',['OVERSAMPLING_16',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7acedf04c432418a93303824703f419950',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f2_383',['OVERSAMPLING_2',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a3f6d80c62d64464c75826d601d878b15',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f4_384',['OVERSAMPLING_4',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a08c7e75e851365b47a7aa08130e0f176',1,'BME_280_Public_Types.h']]],
  ['oversampling_5f8_385',['OVERSAMPLING_8',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a69987d0e93c44cef825208793d2fb612',1,'BME_280_Public_Types.h']]]
];
