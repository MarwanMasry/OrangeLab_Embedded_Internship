var struct_b_m_e__280___config =
[
    [ "I2C_Handle", "struct_b_m_e__280___config.html#a61769d49eaa1253de5a821017d6a2256", null ],
    [ "ProtocolUsed", "struct_b_m_e__280___config.html#aa150afe8037846e20e0ffc859496b7c5", null ],
    [ "SPI_Handle", "struct_b_m_e__280___config.html#a779394057e8f1ceb331758207a1d7561", null ]
];