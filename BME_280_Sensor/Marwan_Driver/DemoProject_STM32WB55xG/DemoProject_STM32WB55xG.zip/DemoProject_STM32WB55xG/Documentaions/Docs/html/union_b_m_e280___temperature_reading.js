var union_b_m_e280___temperature_reading =
[
    [ "__pad0__", "union_b_m_e280___temperature_reading.html#aa7658306695b221e0d809dd5b2f2adbc", null ],
    [ "Data", "union_b_m_e280___temperature_reading.html#abfb157b82ce748f8c785e43dcfd701a7", null ],
    [ "lsb", "union_b_m_e280___temperature_reading.html#af3eddb044f801e81c8562e94b49eaa56", null ],
    [ "msb", "union_b_m_e280___temperature_reading.html#a60008b1db56e327cea3b6fbf970a535d", null ],
    [ "temperature", "union_b_m_e280___temperature_reading.html#a4c1c6f30a9804fbd7ef54ddb152edfc8", null ],
    [ "xlsb", "union_b_m_e280___temperature_reading.html#aec95113e659ddc2482c3ed5852b2aed0", null ]
];