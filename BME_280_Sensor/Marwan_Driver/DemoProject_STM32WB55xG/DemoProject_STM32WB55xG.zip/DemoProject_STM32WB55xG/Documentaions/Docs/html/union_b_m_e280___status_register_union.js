var union_b_m_e280___status_register_union =
[
    [ "__pad0__", "union_b_m_e280___status_register_union.html#a10bdacef0f7eb7ce5582148b2f36c1d8", null ],
    [ "__pad1__", "union_b_m_e280___status_register_union.html#aa5c9283e8f04a95f6fd03751f828c9a7", null ],
    [ "Bits", "union_b_m_e280___status_register_union.html#abe4cb5536334fc2c7af3be32be207f6d", null ],
    [ "config", "union_b_m_e280___status_register_union.html#a5619fae32ba1e40c4bab9f8be90b41e3", null ],
    [ "im_update", "union_b_m_e280___status_register_union.html#a1b43108569cb54f58425059f4418eb18", null ],
    [ "measuring", "union_b_m_e280___status_register_union.html#a3152442abbd7a4b40cfd4a1a058f5d1c", null ]
];