var struct_b_m_e__280__settings =
[
    [ "filterCoeff", "struct_b_m_e__280__settings.html#ab5ef8c18d21d5cddc5f8ea13ee397ee9", null ],
    [ "mode", "struct_b_m_e__280__settings.html#ae734f1a6f575d8e59ac3e1f1223c02eb", null ],
    [ "overSampling_settings", "struct_b_m_e__280__settings.html#a3e3cdd66a0a7ab7a880951e3a47c8543", null ],
    [ "standbyTime", "struct_b_m_e__280__settings.html#af18c4ec6a8836ff8dea48c1062d40631", null ]
];