var searchData=
[
  ['spi3w_5fen_317',['spi3w_en',['../union_b_m_e__280___config_register_union.html#a87ab5cdcba77d8f4c82b93783df76501',1,'BME_280_ConfigRegisterUnion']]],
  ['standbytime_318',['standbyTime',['../struct_b_m_e__280__settings.html#af18c4ec6a8836ff8dea48c1062d40631',1,'BME_280_settings']]],
  ['sw_5fmajor_5fversion_319',['sw_major_version',['../struct_std___version_info_type.html#ad08a3e87fe83d635d0d28fd6e99271af',1,'Std_VersionInfoType']]],
  ['sw_5fminor_5fversion_320',['sw_minor_version',['../struct_std___version_info_type.html#ab27f4e07c28199c14e79d44a3ea09008',1,'Std_VersionInfoType']]],
  ['sw_5fpatch_5fversion_321',['sw_patch_version',['../struct_std___version_info_type.html#af9854c941ce22e88a1718fd2aa183c3c',1,'Std_VersionInfoType']]]
];
