var searchData=
[
  ['skipped_386',['SKIPPED',['../_b_m_e__280___public___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a7b3e3be20ffe941881dfab27e5f6fd7e',1,'BME_280_Public_Types.h']]],
  ['sleep_5fmode_387',['SLEEP_MODE',['../_b_m_e__280___public___types_8h.html#a4c027fadb628675a569c2b1e781b6576ad1486bda2c3e55fd939260a6b7e38020',1,'BME_280_Public_Types.h']]]
];
