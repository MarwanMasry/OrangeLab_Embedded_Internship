var _b_m_e__280__cfg_8h =
[
    [ "BME280_32BIT_COMPENSATING_MEASURMENTS", "_b_m_e__280__cfg_8h.html#a93ef32379cc4a86d7c01fd8e84334998", null ],
    [ "BME280_FLOAT_COMPENSATING_MEASURMENTS", "_b_m_e__280__cfg_8h.html#ae5be14cc0ce1b2161ced439def2d9991", null ],
    [ "CSB_PIN", "_b_m_e__280__cfg_8h.html#a53e04ddabdfb1c2b1fb42acc7074aba9", null ],
    [ "CSB_PIN_PORT", "_b_m_e__280__cfg_8h.html#a475c6736cc5833dd3fc03e73983c16b3", null ],
    [ "MAX_INSTANCE_OF_BME_280_SENSOR", "_b_m_e__280__cfg_8h.html#ac703acd0062c137e6494d996e8bbe945", null ]
];