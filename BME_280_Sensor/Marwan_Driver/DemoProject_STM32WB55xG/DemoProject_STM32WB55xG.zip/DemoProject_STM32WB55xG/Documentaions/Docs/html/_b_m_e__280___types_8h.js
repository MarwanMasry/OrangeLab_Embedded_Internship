var _b_m_e__280___types_8h =
[
    [ "BME_280_OversamplingSettings", "struct_b_m_e__280___oversampling_settings.html", "struct_b_m_e__280___oversampling_settings" ],
    [ "BME_280_settings", "struct_b_m_e__280__settings.html", "struct_b_m_e__280__settings" ],
    [ "BME_280_Config", "struct_b_m_e__280___config.html", "struct_b_m_e__280___config" ],
    [ "BME_280_I2C_Handle", "_b_m_e__280___types_8h.html#a541a83cc8bb01d2f23696f2b05487a9a", null ],
    [ "BME_280_SPI_Handle", "_b_m_e__280___types_8h.html#a0bf18f9970a5cc7f649abf4047caf7b7", null ],
    [ "BME_280_Status", "_b_m_e__280___types_8h.html#a2b81cd700f3d99346bd32b4bff20b125", null ],
    [ "BME_280_CommunicationProtocol", "_b_m_e__280___types_8h.html#ab62b2899dace129af2927b22bd3b409a", [
      [ "BME_280_SPI", "_b_m_e__280___types_8h.html#ab62b2899dace129af2927b22bd3b409aaefec595e93c81edb60e17e4367183430", null ],
      [ "BME_280_I2C", "_b_m_e__280___types_8h.html#ab62b2899dace129af2927b22bd3b409aaf13320aed8c0290ad87a4f4b0beca466", null ]
    ] ],
    [ "BME_280_FilterCoefficient", "_b_m_e__280___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6", [
      [ "FILTER_OFF", "_b_m_e__280___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6ab1577adfe34e9a7249c80578493a2a85", null ],
      [ "_2", "_b_m_e__280___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6a4ac9fde21efe0b04d986336be5ff19ea", null ],
      [ "_4", "_b_m_e__280___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6aa0a2cbf1b2f9a4f01c68830ebc853b96", null ],
      [ "_8", "_b_m_e__280___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6a29bf2b556dc552c594d3f26fd88d4867", null ],
      [ "_16", "_b_m_e__280___types_8h.html#a86a1295f6a9ddaf6c9777a1e06893bd6aa8860397c1b4c5206139a0582a8cad88", null ]
    ] ],
    [ "BME_280_Mode", "_b_m_e__280___types_8h.html#a4c027fadb628675a569c2b1e781b6576", [
      [ "SLEEP_MODE", "_b_m_e__280___types_8h.html#a4c027fadb628675a569c2b1e781b6576ad1486bda2c3e55fd939260a6b7e38020", null ],
      [ "FORCED_MODE", "_b_m_e__280___types_8h.html#a4c027fadb628675a569c2b1e781b6576af93f7214719796eb62d49359c1c5eb05", null ],
      [ "NORMAL_MODE", "_b_m_e__280___types_8h.html#a4c027fadb628675a569c2b1e781b6576a83feb61d42f8db9f494019fcea2c0148", null ]
    ] ],
    [ "BME_280_OversamplingValue", "_b_m_e__280___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7", [
      [ "SKIPPED", "_b_m_e__280___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a7b3e3be20ffe941881dfab27e5f6fd7e", null ],
      [ "OVERSAMPLING_1", "_b_m_e__280___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7afb934501128d3db119c09619681736f0", null ],
      [ "OVERSAMPLING_2", "_b_m_e__280___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a3f6d80c62d64464c75826d601d878b15", null ],
      [ "OVERSAMPLING_4", "_b_m_e__280___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a08c7e75e851365b47a7aa08130e0f176", null ],
      [ "OVERSAMPLING_8", "_b_m_e__280___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7a69987d0e93c44cef825208793d2fb612", null ],
      [ "OVERSAMPLING_16", "_b_m_e__280___types_8h.html#a3962491d1be89fe4f9211f368b87d0d7acedf04c432418a93303824703f419950", null ]
    ] ],
    [ "BME_280_StandbyTimeInNormalMode", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03", [
      [ "_HALF_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03aaf53011d054cb6994521ed9a13f0cecd", null ],
      [ "_62_AND_HALF_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a25343eda9a950ca53191a9907bc59d41", null ],
      [ "_125_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a7996c77b155b3d8f3c9e5f35970f5f29", null ],
      [ "_250_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03afd045a3082d62e4ad74d3c76f51d9108", null ],
      [ "_500_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a126b23d9a5e1b2ccc0fcc1cfa73484b0", null ],
      [ "_1000_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03ae025f4c99442d9a61023739eecdd65f0", null ],
      [ "_10_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a18a8d67e4539244782d601b46df7e9d0", null ],
      [ "_20_MS", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a20f6959900f2ff118ab6957c629b17a2", null ],
      [ "NO_STANDBY_TIME_NOT_IN_NORMAL_MODE", "_b_m_e__280___types_8h.html#a27f7f438c823a2bfb98e78fdfcd47e03a1804730b010c1fe93b04c9e90299d306", null ]
    ] ]
];