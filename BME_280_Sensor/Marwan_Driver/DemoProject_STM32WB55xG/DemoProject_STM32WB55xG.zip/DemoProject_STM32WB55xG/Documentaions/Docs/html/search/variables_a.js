var searchData=
[
  ['occupied_311',['occupied',['../struct_b_m_e__280___configurations.html#a2241dca6736e4dcc9d0d92968fa2378c',1,'BME_280_Configurations']]],
  ['osrs_5fp_312',['osrs_p',['../union_b_m_e280___ctrl_meas_register_union.html#a600854065c5caee2ea975d52dc773a9b',1,'BME280_CtrlMeasRegisterUnion']]],
  ['osrs_5ft_313',['osrs_t',['../union_b_m_e280___ctrl_meas_register_union.html#a237e8236e986649b7229452d2af5ae98',1,'BME280_CtrlMeasRegisterUnion']]],
  ['oversampling_5fsettings_314',['overSampling_settings',['../struct_b_m_e__280__settings.html#a3e3cdd66a0a7ab7a880951e3a47c8543',1,'BME_280_settings']]]
];
