var struct_b_m_e__280___configurations =
[
    [ "calib1", "struct_b_m_e__280___configurations.html#a4778330b024ccba611427f8b017e5cff", null ],
    [ "calib2", "struct_b_m_e__280___configurations.html#a9da0ce6be2e67d9dae24596a6d184924", null ],
    [ "occupied", "struct_b_m_e__280___configurations.html#a2241dca6736e4dcc9d0d92968fa2378c", null ],
    [ "ProtocolUsed", "struct_b_m_e__280___configurations.html#a41de6c24a5993075d0fa45e170f8cc8a", null ]
];