var searchData=
[
  ['vendorid_219',['vendorID',['../struct_std___version_info_type.html#a26055f45e3016862f87063d1feccea8d',1,'Std_VersionInfoType']]]
];
